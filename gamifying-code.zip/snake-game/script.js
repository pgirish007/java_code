const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
let box = 20;
let snake = [{x: 9*box, y: 9*box}];
let direction = null;
let food = {x: Math.floor(Math.random()*20)*box, y: Math.floor(Math.random()*20)*box};
document.addEventListener('keydown', e => {
    if (e.key === 'ArrowUp' && direction !== 'DOWN') direction = 'UP';
    if (e.key === 'ArrowDown' && direction !== 'UP') direction = 'DOWN';
    if (e.key === 'ArrowLeft' && direction !== 'RIGHT') direction = 'LEFT';
    if (e.key === 'ArrowRight' && direction !== 'LEFT') direction = 'RIGHT';
});
function draw() {
    ctx.clearRect(0, 0, 400, 400);
    snake.forEach(s => { ctx.fillStyle = 'lime'; ctx.fillRect(s.x, s.y, box, box); });
    ctx.fillStyle = 'red'; ctx.fillRect(food.x, food.y, box, box);
    let headX = snake[0].x;
    let headY = snake[0].y;
    if (direction === 'UP') headY -= box;
    if (direction === 'DOWN') headY += box;
    if (direction === 'LEFT') headX -= box;
    if (direction === 'RIGHT') headX += box;
    if (headX === food.x && headY === food.y) {
        food = {x: Math.floor(Math.random()*20)*box, y: Math.floor(Math.random()*20)*box};
    } else {
        snake.pop();
    }
    let newHead = {x: headX, y: headY};
    if (headX < 0 || headY < 0 || headX >= 400 || headY >= 400 || snake.some(s => s.x === headX && s.y === headY)) {
        clearInterval(game);
        alert('Game Over!');
    }
    snake.unshift(newHead);
}
let game = setInterval(draw, 100);