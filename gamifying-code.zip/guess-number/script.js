let number = Math.floor(Math.random() * 100) + 1;
function checkGuess() {
    let guess = document.getElementById('guess').value;
    let msg = document.getElementById('message');
    if (!guess) return;
    if (guess == number) msg.textContent = '🎉 Correct!';
    else if (guess > number) msg.textContent = '📉 Too high!';
    else msg.textContent = '📈 Too low!';
}