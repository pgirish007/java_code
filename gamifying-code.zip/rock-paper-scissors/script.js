function play(choice) {
    const options = ['rock', 'paper', 'scissors'];
    const computer = options[Math.floor(Math.random() * 3)];
    let result = '';
    if (choice === computer) result = "It's a tie!";
    else if ((choice === 'rock' && computer === 'scissors') || 
             (choice === 'paper' && computer === 'rock') || 
             (choice === 'scissors' && computer === 'paper')) result = 'You win!';
    else result = 'You lose!';
    document.getElementById('result').textContent = `You: ${choice} | Computer: ${computer} → ${result}`;
}