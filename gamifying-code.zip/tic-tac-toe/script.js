let board = ['', '', '', '', '', '', '', '', ''];
let current = 'X';
const winPatterns = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const boardDiv = document.getElementById('board');
const status = document.getElementById('status');
board.forEach((_, i) => {
    let cell = document.createElement('div');
    cell.className = 'cell';
    cell.addEventListener('click', () => makeMove(i, cell));
    boardDiv.appendChild(cell);
});
function makeMove(i, cell) {
    if (board[i] || checkWin()) return;
    board[i] = current;
    cell.textContent = current;
    if (checkWin()) status.textContent = `${current} wins!`;
    else current = current === 'X' ? 'O' : 'X';
}
function checkWin() {
    return winPatterns.some(p => board[p[0]] && board[p[0]] === board[p[1]] && board[p[1]] === board[p[2]]);
}