# 🕵️ Prompt Arena: **BugPromptHunt**

Turn debugging into a game. Leaders practice **prompt engineering** by guiding an AI assistant to find, explain, and fix bugs across multiple stacks (Python, Java, Ansible, Puppet).

## 🎯 Objective
Use **structured prompts** to:
1) Identify the bug, 2) Explain the root cause, 3) Provide/verify a fix, 4) Capture the key learning.

## 🧭 Flow
1. Pick an artifact from `/artifacts/<stack>/`.
2. Open `template.md`, craft your **first prompt**.
3. Paste the **artifact** and **error/output** into your prompt.
4. Iterate: refine the prompt for clarity, constraints, formatting.
5. Save your final prompt + the AI’s answer in `/solutions/<yourname>_response.md`.

## 🧪 Acceptance
- Clear prompt with context + goal + constraints.
- AI response contains **Cause**, **Fixed Code/Steps**, **Learning** in requested format.
- Optional: you validated the fix locally (tests or manual run).

## 🏆 Scoring (see `rubric.md`)
- Effectiveness, Efficiency, Clarity, Knowledge Gain, Validation.

## 📁 Contents
- `example_prompt.md` — a worked example.
- `template.md` — use this structure to write your prompt.
- `rubric.md` — scoring guidelines.
- `facilitator_guide.md` — how to run this activity.
- `artifacts/` — buggy samples for Python, Java, Ansible, Puppet.
- `solutions/` — place your final prompt + AI response here.

---

### 🔧 Tips
- Tell the AI **who to be** (role), **what to return** (format), and **what constraints** to follow.
- Include the **exact error message** and **full minimal snippet**.
- Ask it to **explain before fixing**.
- Request a **short “Key Learning”** section for leadership takeaways.
