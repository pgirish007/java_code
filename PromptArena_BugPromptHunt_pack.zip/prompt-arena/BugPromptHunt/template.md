# BugPromptHunt — Prompt Template

Copy this into a new file under `solutions/yourname_response.md` and fill it in.

## Context
- Role for AI (e.g., "Act as a senior DevOps/Python/Java/Puppet/Ansible engineer.")
- My goal in one sentence.

## Artifact (paste the minimal, complete snippet)
```<language or tool>
# your code / manifest / playbook goes here
```

## Error or Observed Behavior
```
# paste exact error output, failing test, or incorrect behavior description
```

## Task
- What must the AI deliver? (Cause + Fix + Learning)
- Any extra requests? (e.g., alternative solution, edge cases)

## Constraints
- Output format (e.g., 3 sections with headings).
- Word limits, style, or environment assumptions.
- Anything to avoid (e.g., "don’t change interfaces").

## (Expected Structure of AI Response)
### Cause
### Fixed Code / Steps
### Key Learning
