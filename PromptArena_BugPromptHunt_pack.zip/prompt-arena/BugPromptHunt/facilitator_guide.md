# Facilitator Guide — BugPromptHunt

## Purpose
Teach leaders to **guide AI** like a junior engineer: provide context, ask for structure, validate output.

## Timing (45–60 min)
- 5 min: Intro & demo the example prompt.
- 20–30 min: Solo/paired BugPromptHunt.
- 10 min: Demos (1 min each).
- 10–15 min: Debrief + scoring.

## Flow
1. Participants pick a stack and an artifact under `/artifacts`.
2. They use `template.md` to craft and iterate their prompt.
3. They paste final **prompt + AI response** in `solutions/<name>_response.md`.
4. Reviewers score using `rubric.md`.

## Debrief Questions
- What context detail most improved the AI’s answer?
- What structure request (headings/format) helped validation?
- How would you reuse this prompt format next time?

## Variations
- **Time Attack**: most effective result under 10 minutes wins.
- **Contrast**: two leaders solve the same artifact in different stacks.
- **Edge Case Bonus**: ask AI for 2 corner cases and verify them.
