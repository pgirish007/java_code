# Buggy Python artifact (JSON parsing)
import json
data = "{'name': 'Sam'}"  # BUG: JSON must use double quotes
parsed = json.loads(data)
print(parsed['name'])
