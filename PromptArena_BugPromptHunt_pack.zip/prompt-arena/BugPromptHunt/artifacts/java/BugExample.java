// Buggy Java artifact (String comparison)
public class BugExample {
    public static void main(String[] args) {
        String status = new String("READY");
        if (status == "READY") { // BUG: use equals() for string comparison
            System.out.println("System is ready");
        } else {
            System.out.println("System is NOT ready");
        }
    }
}
