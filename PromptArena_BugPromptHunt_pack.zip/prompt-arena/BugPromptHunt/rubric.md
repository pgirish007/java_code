# BugPromptHunt — Scoring Rubric

| Dimension        | 0–2 (Needs Work)                                       | 3–4 (Solid)                                                       | 5 (Excellent)                                                      |
|------------------|---------------------------------------------------------|-------------------------------------------------------------------|-------------------------------------------------------------------|
| Effectiveness    | Doesn’t solve root issue                                | Identifies cause, fix mostly correct                              | Pinpoints cause and provides a verified, minimal correct fix      |
| Efficiency       | Many iterations, meandering prompts                     | 2–3 iterations, generally focused                                 | 1–2 iterations, crisp prompting                                   |
| Clarity          | Vague, missing context or error                         | Clear context, goal, and constraints                              | Exceptionally clear; reusable template-quality prompt             |
| Knowledge Gain   | No clear lesson                                         | States a useful takeaway                                          | Concise, leadership-relevant learning captured                    |
| Validation       | No proof of fix                                         | Basic validation (compiles/tests)                                 | Strong validation (tests, idempotence checks, or run logs)        |

**Total:** /25  
**Notes for reviewer:** Capture what made this entry stand out and what could be improved.
