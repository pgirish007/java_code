# BugPromptHunt — Example Prompt (Python)

## Context
Act as a **senior debugging assistant**. I am a CTO infra leader practicing prompt engineering.

## Artifact (Python)
```python
import json
data = "{'name': 'Sam'}"
parsed = json.loads(data)
print(parsed['name'])
```

## Error
```
json.decoder.JSONDecodeError: Expecting property name enclosed in double quotes
```

## Task
Find the bug, explain **why** it fails, then provide corrected code.  
Return answer in exactly three sections with headings:  
1) **Cause**, 2) **Fixed Code**, 3) **Key Learning**.

## Constraints
- Keep explanation under 120 words.
- Code must be runnable as-is.
- Do not change overall logic.

## (Expected Structure of AI Response)
### Cause
...
### Fixed Code
```python
# corrected code here
```
### Key Learning
...
