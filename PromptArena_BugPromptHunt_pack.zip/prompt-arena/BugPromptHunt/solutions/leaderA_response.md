# BugPromptHunt Solution — Leader A (Python)

## Final Prompt
Act as a **senior Python debugging assistant**. Diagnose and fix the bug below.
Return exactly three sections with headings: **Cause**, **Fixed Code**, **Key Learning**.
Keep explanation under 120 words.

```python
import json
data = "{'name': 'Sam'}"
parsed = json.loads(data)
print(parsed['name'])
```

Error:
```
json.decoder.JSONDecodeError: Expecting property name enclosed in double quotes
```

## AI Response
### Cause
The JSON string uses single quotes. JSON requires **double quotes** around property names and string values, so `json.loads` fails to parse.

### Fixed Code
```python
import json
data = "{\"name\": \"Sam\"}"
parsed = json.loads(data)
print(parsed["name"])
```

### Key Learning
JSON ≠ Python dicts. Use double quotes in JSON and prefer validating with `json.loads` on minimal examples.
