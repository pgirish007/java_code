# BugPromptHunt Solution — Leader B (Ansible)

## Final Prompt
Act as a **senior Ansible engineer**. Explain why this playbook fails and provide a corrected version.
Return **Cause**, **Fixed Playbook**, **Key Learning**. Keep explanation under 120 words.

```yaml
---
- hosts: web
  gather_facts: false
  tasks:
    - name: Install nginx
      apt:
        name: nginx
        state: present
    - name: Start nginx service
      service:
        name: nginx
        state: starteded
```

Error (abridged):
```
FAILED! => {"msg": "value of state must be one of: started, stopped, restarted, reloaded"}
```

## AI Response
### Cause
The `service` task uses an invalid state `starteded`. Valid values include `started` and `stopped`.

### Fixed Playbook
```yaml
---
- hosts: web
  become: true
  gather_facts: false
  tasks:
    - name: Install nginx
      apt:
        name: nginx
        state: present
        update_cache: yes
    - name: Ensure nginx is running
      service:
        name: nginx
        state: started
        enabled: true
```

### Key Learning
Validate module parameters. Add `become: true` when managing packages/services and ensure idempotent states.
